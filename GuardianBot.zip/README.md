# GuardianBot
Cortafuegos contra DDOS para Linux de alto rendimeinto basado en eBPF XDP.

*Mapas hash para sumar por cada valor de cada CPU del núcleo
*Memoria compartida con python (interfaz) para actualizar las tablas IPV6 e IPV4
*Compatibilidad con IPV6
