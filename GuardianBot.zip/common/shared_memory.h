#ifndef __SHARED_MEMORY_H
#define __SHARED_MEMORY_H




int send_to_python(char * data, int tam);
#endif /* __SHARED_MEMORY_H */
